# Meal Printer
Mid-to-late game automated meal production for Rimworld

**Author:** SomewhereOutInSpace

**Attributions:** Robin "sumghai" Chang (sumdumghai@gmail.com) and Dubwise, for Harmony and UI code from their Replimat mod used here under CC BY-SA 4.0.

**License:** [Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)](http://www.creativecommons.org/licenses/by-sa/4.0/)

[**Steam Workshop Page**](https://steamcommunity.com/sharedfiles/filedetails/?id=2552068105)