This mod is licenced under [Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)](http://www.creativecommons.org/licenses/by-sa/4.0/), which in layman's terms means:

- You are permitted to use, copy, redistribute my work as-is

- You may remix your own derivatives (new models, alternative textures, plugin code), and release them under your own name

- You must credit **SomewhereOutInSpace (author, Meal Printer), Robin "sumghai" Chang and Dubwise56 (authors, Replimat)** when publishing your derivatives in the download and forum posts